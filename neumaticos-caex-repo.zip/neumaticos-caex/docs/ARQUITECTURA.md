# Arquitectura

**Frontend** (React/Vite a futuro; hoy HTML + JS) → **API FastAPI** → **PostgreSQL**
La **visión por computador** corre como proceso aparte y escribe mediciones en la base.

## Rutas del frontend
`/` tablero · `/neumatico/:serial` ficha · `/agendar/:serial` agenda · `/orden/:id` orden

## Modelo de datos
- `neumatico`: serial, marca, caex, posicion, umbral_retiro_mm
- `medicion`: neumatico_id, fecha_pasada, horas_operacion, profundidad_mm, imagen_url, modelo_version
- `dano`: neumatico_id, tipo, fecha
- `ventana_taller`: fecha, turno, cupos_totales, cupos_ocupados
- `orden_trabajo`: codigo, neumatico_id, ventana_id, medicion_id, estado, creada_en

## API
| Método | Ruta | Descripción |
|---|---|---|
| GET | `/turnos/{fecha}/neumaticos` | Lista con horas restantes y semáforo |
| GET | `/neumaticos/{serial}` | Ficha, historial y proyección |
| GET | `/neumaticos/{serial}/ventanas` | Ventanas con indicador de margen |
| POST | `/ordenes` | Crea la orden de trabajo |

## Proyección
Regresión lineal de profundidad contra horas de operación. Horas remanentes = (horas al cruzar el umbral) - (horas actuales). Semáforo: rojo < 300 h, amarillo < 600 h, verde el resto (valores a validar con mantenimiento).

## Visión por computador (hoja de ruta)
1. Captura fija en el punto de pasada. 2. Detección de neumático y lectura del serial (detector + OCR). 3. Profundidad: sensor láser o perfil 3D (preferible) o modelo solo con imágenes. 4. Detección de daños. 5. Registro con `modelo_version` para trazabilidad.
Validar siempre contra medición manual: polvo, barro y luz afectan la precisión.
