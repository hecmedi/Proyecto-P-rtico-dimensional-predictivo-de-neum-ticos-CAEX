"""API base con datos de ejemplo en memoria. Reemplazar por PostgreSQL."""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .proyeccion import proyectar_horas, semaforo, tasa_desgaste_por_100h

app = FastAPI(title="Control de neumáticos CAEX")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

UMBRAL_MM = 30.0
MODELO_VERSION = "v1.3"


def _hist(horas_rest: float, tasa=0.42, n=8, paso_h=100):
    """Historial sintético: profundidad por pasada que llega a la proyección dada."""
    fin = UMBRAL_MM + horas_rest * tasa / 100
    return [(i * paso_h, round(fin + (n - 1 - i) * tasa, 2)) for i in range(n)]


NEUMATICOS = {
    s: {"serial": s, "caex": c, "posicion": p, "marca": m, "dano": d, "mediciones": _hist(h)}
    for s, c, p, m, h, d in [
        ("BRG-59034-11", "CAEX 12", 1, "Bridgestone", 140, "corte en flanco, 22-09"),
        ("MCH-22871-03", "CAEX 07", 4, "Michelin", 260, None),
        ("BKT-40192-77", "CAEX 21", 2, "BKT", 480, None),
        ("BRG-51120-09", "CAEX 03", 6, "Bridgestone", 910, None),
        ("MCH-30455-12", "CAEX 15", 3, "Michelin", 1240, None),
    ]
}

VENTANAS = [
    {"id": 1, "dia": "Jueves 25", "turno": "noche", "libres": 2, "horas_hasta": 36},
    {"id": 2, "dia": "Viernes 26", "turno": "día", "libres": 1, "horas_hasta": 56},
    {"id": 3, "dia": "Sábado 27", "turno": "noche", "libres": 3, "horas_hasta": 84},
]
ORDENES: list[dict] = []


def _resumen(n: dict) -> dict:
    h = proyectar_horas(n["mediciones"], UMBRAL_MM)
    return {**{k: n[k] for k in ("serial", "caex", "posicion", "marca")},
            "horas_restantes": round(h) if h is not None else None,
            "semaforo": semaforo(h) if h is not None else "verde"}


@app.get("/turnos/{fecha}/neumaticos")
def tablero(fecha: str):
    filas = [_resumen(n) for n in NEUMATICOS.values()]
    return sorted(filas, key=lambda f: f["horas_restantes"] if f["horas_restantes"] is not None else 1e9)


@app.get("/neumaticos/{serial}")
def ficha(serial: str):
    n = NEUMATICOS.get(serial)
    if not n:
        raise HTTPException(404, "Neumático no encontrado")
    return {**_resumen(n), "ultimo_dano": n["dano"], "umbral_mm": UMBRAL_MM,
            "tasa_mm_por_100h": tasa_desgaste_por_100h(n["mediciones"]),
            "historial": [{"horas": h, "profundidad_mm": p} for h, p in n["mediciones"]]}


@app.get("/neumaticos/{serial}/ventanas")
def ventanas(serial: str):
    n = NEUMATICOS.get(serial)
    if not n:
        raise HTTPException(404, "Neumático no encontrado")
    h = proyectar_horas(n["mediciones"], UMBRAL_MM) or 0
    return [{**v, "dentro_del_margen": v["horas_hasta"] < h} for v in VENTANAS]


class NuevaOrden(BaseModel):
    serial: str
    ventana_id: int


@app.post("/ordenes", status_code=201)
def crear_orden(body: NuevaOrden):
    n = NEUMATICOS.get(body.serial)
    v = next((x for x in VENTANAS if x["id"] == body.ventana_id), None)
    if not n or not v:
        raise HTTPException(404, "Neumático o ventana no encontrados")
    if v["libres"] < 1:
        raise HTTPException(409, "La ventana no tiene cupos libres")
    v["libres"] -= 1
    orden = {"codigo": f"OT-2026-{918 + len(ORDENES):04d}", "serial": n["serial"], "caex": n["caex"],
             "posicion": n["posicion"], "ventana": f'{v["dia"]}, turno {v["turno"]}',
             "modelo_version": MODELO_VERSION}
    ORDENES.append(orden)  # TODO: escribir en ERP y notificar al taller
    return orden
