# Avances

## v0.1 (actual)
- [x] Wireframe de 4 pantallas definido
- [x] Prototipo frontend navegable con datos de ejemplo (`frontend/index.html`)
- [x] Backend base con datos de ejemplo: proyección lineal, semáforo, ventanas, creación de órdenes
- [x] Pruebas unitarias de proyección y semáforo

## Pendiente
- [ ] Conectar el frontend a la API (reemplazar los datos de ejemplo)
- [ ] Base de datos real (PostgreSQL) y migraciones
- [ ] Captura de imágenes y modelo de visión (detección, OCR del serial, profundidad, daños)
- [ ] Validación de las mediciones contra medición manual en terreno
- [ ] Integración con el ERP y notificación al taller
- [ ] Autenticación y roles (planificador, taller)
- [ ] Despliegue con Docker Compose
