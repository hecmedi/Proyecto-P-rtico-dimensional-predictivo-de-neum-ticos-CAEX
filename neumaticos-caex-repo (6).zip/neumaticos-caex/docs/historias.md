# Historias de usuario y criterios de aceptación

> **Borrador del Equipo 3 (Semana 4).** Se construyó a partir de los Avances 1 y 2. El recorrido y los puntos de dolor son **hipótesis** que deben confirmarse con una entrevista a un planificador de Mantención de Neumáticos antes de dar el backlog por cerrado.

## Niveles de daño (definición de trabajo)

La plataforma clasifica cada neumático según el daño visible y el camión según su neumático más grave. Los niveles y sus umbrales son una **hipótesis a validar** con Mantención y con el proveedor.

| Nivel | Nombre | Significado operacional |
|---|---|---|
| 0 | Sin daño | Opera con normalidad |
| 1 | Leve | Observación en las próximas pasadas |
| 2 | Moderado | Programar intervención en la próxima ventana del taller |
| 3 | Crítico | Sacar el CAEX del ciclo y alertar de inmediato |

Tipos de daño que detecta el modelo: corte, rajadura, roca incrustada, desgaste irregular y otros por definir. **Nivel del camión = nivel máximo de sus seis neumáticos.**

## Recorrido del usuario (hipótesis)

Actor: planificador de Mantención de Neumáticos, al inicio de cada turno.

| Etapa | Acción | Lo que piensa (por recoger en entrevista) | Punto de dolor |
|---|---|---|---|
| 1. Revisa la flota | Busca qué CAEX requieren atención | «Quiero saber cuáles son los críticos antes de empezar» | **D1** Inspección por muestreo: no ve toda la flota |
| 2. Evalúa un neumático | Revisa el daño y su historia | «¿Qué tan grave es y desde cuándo?» | **D2** Evaluación subjetiva y sin historia por serial |
| 3. Agenda | Busca una ventana en el taller | «Que alcance antes de que falle» | **D3** Un daño crítico se detecta tarde |
| 4. Emite la orden | Registra la orden en el ERP | «No quiero escribir esto de nuevo» | **D4** Se reescribe la orden y se pierde la evidencia |

## Backlog

Orden según la secuencia real de uso. Las historias del **flujo principal** (pantallas P1 a P4) están marcadas con ★.

| Código | Historia | Origen |
|---|---|---|
| HU-01 ★ | Ver la flota clasificada por nivel de daño | D1 |
| HU-02 ★ | Ver la ficha del neumático con fotos y daños detectados | D2 |
| HU-03 | Recibir alerta inmediata de un daño crítico | D3 |
| HU-04 ★ | Agendar la intervención en una ventana del taller | D3 |
| HU-05 ★ | Emitir la orden con trazabilidad a la medición | D4 |
| HU-06 | Fotografiar cada CAEX en una sola pasada | D1 |
| HU-07 | Identificar el neumático por serial y posición | D2 |
| HU-08 | Corregir una clasificación del modelo | D2 |

---

## HU-01 ★ Ver la flota clasificada por nivel de daño
**Como** planificador de Mantención de Neumáticos, **quiero** ver al iniciar el turno la flota ordenada por el nivel de daño de cada camión, **para** decidir primero sobre los más críticos sin inspeccionar camión por camión.

**Escenario principal**
- **Dado** que el turno tiene camiones fotografiados en la última pasada
- **Cuando** abro el tablero del turno
- **Entonces** veo cada CAEX con su nivel (0 a 3) y color, ordenado del más grave al menos grave

**Escenario alternativo**
- **Dado** que un CAEX no se fotografió en la última pasada
- **Cuando** abro el tablero
- **Entonces** aparece como «sin medición reciente» con la fecha de su última pasada

## HU-02 ★ Ver la ficha del neumático con fotos y daños detectados
**Como** planificador, **quiero** abrir un neumático y ver sus fotos con los daños marcados y su historia, **para** confirmar la gravedad con evidencia y no con una impresión.

**Escenario principal**
- **Dado** que selecciono un neumático en nivel 2 o 3
- **Cuando** abro su ficha
- **Entonces** veo la foto con cada daño marcado, su tipo, su nivel y la fecha de la pasada

**Escenario alternativo**
- **Dado** que el modelo detectó un daño con baja confianza
- **Cuando** abro la ficha
- **Entonces** el daño aparece señalado como «por confirmar»

## HU-03 Recibir alerta inmediata de un daño crítico
**Como** despachador, **quiero** recibir de inmediato la alerta cuando un neumático queda en nivel 3, **para** sacar el CAEX del ciclo antes de que falle en operación.

**Escenario principal**
- **Dado** que un neumático se clasifica en nivel 3
- **Cuando** termina el análisis de la pasada
- **Entonces** el despachador y el planificador reciben una alerta con el CAEX, la posición y la foto

**Escenario alternativo**
- **Dado** que la alerta no se confirma como recibida
- **Cuando** pasan los minutos definidos por la faena
- **Entonces** el sistema la reenvía y la marca como pendiente en el tablero

## HU-04 ★ Agendar la intervención en una ventana del taller
**Como** planificador, **quiero** elegir una ventana libre del taller para un neumático crítico, **para** que la intervención ocurra antes de que el daño avance.

**Escenario principal**
- **Dado** que estoy en la ficha de un neumático en nivel 2 o 3
- **Cuando** pido agendar y elijo una ventana con cupos
- **Entonces** el sistema reserva un cupo y muestra el resumen para confirmar

**Escenario alternativo**
- **Dado** que la ventana elegida no tiene cupos libres
- **Cuando** intento confirmarla
- **Entonces** el sistema lo impide y propone la siguiente ventana disponible

## HU-05 ★ Emitir la orden con trazabilidad
**Como** planificador, **quiero** que al confirmar se emita la orden en el ERP con su vínculo a la medición, **para** no reescribirla y contar con evidencia en la reunión semanal y frente al proveedor.

**Escenario principal**
- **Dado** que confirmé una ventana
- **Cuando** emito la orden
- **Entonces** veo el código de la orden, el neumático, la ventana y la fecha de la pasada con la versión del modelo

**Escenario alternativo**
- **Dado** que el ERP rechaza la orden
- **Cuando** intento emitirla
- **Entonces** veo el motivo, la orden queda pendiente y puedo reintentar sin perder la reserva

## HU-06 Fotografiar cada CAEX en una sola pasada
**Como** operador del punto de control, **quiero** que cada camión quede fotografiado al pasar sin detenerse, **para** no frenar el ciclo ni depender de una inspección manual.

**Escenario principal**
- **Dado** que un CAEX cruza el punto de control a velocidad de tránsito
- **Cuando** el sistema detecta su paso
- **Entonces** quedan registradas las fotos de sus seis neumáticos con fecha y hora

**Escenario alternativo**
- **Dado** que una foto sale borrosa u oscura
- **Cuando** el sistema evalúa su calidad
- **Entonces** la descarta y marca el neumático como «sin medición» para reintentar en la próxima pasada

## HU-07 Identificar el neumático por serial y posición
**Como** planificador, **quiero** que cada foto quede asociada al serial y a la posición del neumático, **para** tener su historia individual.

**Escenario principal**
- **Dado** que se procesa una foto
- **Cuando** el sistema lee el serial grabado en el flanco
- **Entonces** la foto queda en la historia de ese serial y posición

**Escenario alternativo**
- **Dado** que el serial no se puede leer
- **Cuando** terminan las pasadas definidas sin lograrlo
- **Entonces** se crea una tarea de verificación manual con la foto adjunta

## HU-08 Corregir una clasificación del modelo
**Como** planificador, **quiero** corregir el tipo o el nivel de un daño mal clasificado, **para** que el modelo mejore y la ficha refleje la realidad.

**Escenario principal**
- **Dado** que estoy en la ficha con un daño mal clasificado
- **Cuando** lo corrijo e indico el motivo
- **Entonces** la ficha muestra la corrección con mi nombre y la fecha, y la foto queda guardada para reentrenar

**Escenario alternativo**
- **Dado** que la corrección cambia el nivel del camión
- **Cuando** la guardo
- **Entonces** el nivel del camión en el tablero se actualiza

---

## Revisión INVEST

Antes de comprometer cada historia, preguntarse: ¿Independiente? ¿Negociable? ¿Valiosa fuera del equipo? ¿Estimable? ¿Pequeña (cabe en un sprint)? ¿Comprobable?
**Candidatas a dividir:** HU-06 y HU-07 dependen del hardware y de un modelo de visión; si no caben en un sprint, separar la captura, la lectura del serial y la clasificación en historias propias. Mientras no exista el punto de control, trabajar con fotos de ejemplo.
